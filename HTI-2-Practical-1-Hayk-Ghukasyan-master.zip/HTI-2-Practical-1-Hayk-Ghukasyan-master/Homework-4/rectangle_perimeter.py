import math

x1 = float(input(": "))
y1 = float(input(": "))
x2 = float(input(": "))
y2 = float(input(": "))
x3 = float(input(": "))
y3 = float(input(": "))
x4 = float(input(": "))
y4 = float(input(": "))


def segment_length(x1, y1, x2, y2):
    segment = math.sqrt(math.pow(x2 - x1, 2) + math.pow(y2 - y1, 2))
    return segment


segment1 = segment_length(x1, y1, x2, y2)
segment2 = segment_length(x1, y1, x4, y4)

p = 2 * (segment2 + segment1)
print(p)
