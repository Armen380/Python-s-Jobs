def is_prime(num):
    for i in range(2, num // 2):
        if num % i == 0:
            return False
        else:
            return True


def goldbach_s_conjecture(num):
    for i in range(2, num):

        if is_prime(i) and is_prime(num - i):
            print(i, num - i)
            break


num = int(input())

while num % 2 != 0:
    num = int(input())

goldbach_s_conjecture(num)
