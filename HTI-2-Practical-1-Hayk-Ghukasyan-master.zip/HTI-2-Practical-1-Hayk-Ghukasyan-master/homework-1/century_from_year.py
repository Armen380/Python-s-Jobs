year = int(input())

if year % 100 == 0:
    year = year // 100
    print(year)
else:
    year = year // 100 + 1
    print(year)

