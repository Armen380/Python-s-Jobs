Progres1 = int(input())
Progres2 = int(input())
N = int(input())

sum = Progres1 + (Progres2 - Progres1) * (N - 1)

print(f'[{N}] = {sum}')
