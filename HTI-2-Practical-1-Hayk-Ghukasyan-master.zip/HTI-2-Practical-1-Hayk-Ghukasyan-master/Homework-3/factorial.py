def num():
    numbers = int(input())
    factorial(numbers)


def factorial(num):
    for i in range(1, num):
        num = num * i
    print(num)

num()