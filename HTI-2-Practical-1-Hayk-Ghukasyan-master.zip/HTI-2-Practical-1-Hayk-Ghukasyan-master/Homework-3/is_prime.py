def num():
    num = int(input(": "))
    is_prime(num)


def is_prime(num):
    for i in range(2, num // 2):
        if num % i == 0:
            print("No")
            break
        else:
            print("Yes")
            break


num()
