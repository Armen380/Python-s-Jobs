def input_num():
    num = int(input("Введите целое: "))
    result = number_root(num)
    while result >= 10:
        result = number_root(result)
    print(result)


def number_root(num):
    sum = 0
    while num != 0:
        sum = sum + num % 10
        num = num // 10
    return sum


input_num()