def roman_to_integer(num):
    roman = {"I": 1,
             "V": 5,
             "X": 10,
             "L": 50,
             "C": 100,
             "D": 500,
             "M": 1000}

    res = 0

    i = len(num) - 1

    while i >= 0:

        if i != 0:

            if roman.get(num[i]) > roman.get(num[i - 1]):

                res += roman.get(num[i])

                res -= roman.get(num[i - 1])

                i -= 2

            else:
                res += roman.get(num[i])

                i -= 1
        else:
            res += roman.get(num[i])

            i -= 1
    print(res)


num = input().upper()

roman_to_integer(num)
