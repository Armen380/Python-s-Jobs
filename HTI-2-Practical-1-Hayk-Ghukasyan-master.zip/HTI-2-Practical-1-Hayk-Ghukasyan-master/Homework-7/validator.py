import sys
import re


def validate_phone_number(value):

    petter = (
        r'(^(77|98|55|99|91))((((\s?|-?)\d{3}){2})|(((\s?|-?)\d{2}){3}))|(^0(77|98|55|99|91))((((\s?|-?)\d{3}){2})|(((\s?|-?)\d{2}){3}))$')

    number_re = re.compile(petter)

    if number_re.findall(value):
        print("Yes")
    else:
        print("No")





def validate_email(value):

    petter = (
        r'^((([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6})$')

    words_re = re.compile(petter)

    if words_re.findall(value):
        print("Yes")
    else:
        print("No")



if len(sys.argv) == 3:


    command = sys.argv[1]
    value = sys.argv[2]
    if command == "phone_number":

        validate_phone_number(value)

    elif command == "email":

        validate_email(value)
    else:

        print("No such command.")

elif len(sys.argv) == 2:
    print("No value passed.")

else:
    print("Type one of the following commands.\nemail\nphone_number")




