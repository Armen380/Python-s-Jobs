def number_guesser():
    print("Think of a number between 1 and 999. Input 0 once you’re ready to play")

    mid = 500
    maximum, minimum = 1000, 0
    i = 1
    answer = 1

    while answer != 0:

        if i > 10:
            print("I couldn’t guess in 10 steps! This means you cheated!")
            break

        print("I thinks its", mid)
        answer = int(input())

        if answer == 1:
            minimum = mid
            mid += (maximum - mid) // 2
            i += 1

        if answer == -1:
            maximum = mid
            mid -= (mid - minimum) // 2
            i += 1

        if answer == 0:
            print("I guessed in", i, "steps")
            break


number_guesser()
