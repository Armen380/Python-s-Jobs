import random


def get_a_random_line():
    with open("fruits.txt") as f:
        word = random.choice([line for line in f.readlines()])
    return word


def hangman():
    word = get_a_random_line()

    word_completion = "_" * len(word)

    guessed = False

    guessed_letters = []

    guessed_words = []

    mistakes = 5

    print(word_completion)

    print("\n")

    while not guessed and mistakes > 0:
        guess = input("Guess the word. ")
        print(mistakes, "mistakes left. ")
        if len(guess) == 1:
            if guess in guessed_letters:

                print("You already guessed the letter", guess)

            elif guess not in word:

                print(guess, "is not in the word")
                mistakes -= 1
                guessed_letters.append(guess)
            else:

                guessed_letters.append(guess)

                word_as_list = list(word_completion)

                indices = [i for i, letter in enumerate(word) if letter == guess]

                for index in indices:
                    word_as_list[index] = guess

                word_completion = "".join(word_as_list)

                if "_" not in word_completion:
                    guessed = True

        elif len(guess) == len(word):

            if guess in guessed_words:

                print("You already guessed the word", guess)

            elif guess != word:

                print(guess, "is not the word")

                mistakes -= 1

                guessed_words.append(guess)
            else:
                guessed = True
                word_completion = word

        else:
            print("Not a valid guess")

        print(word_completion)

        print("\n")

    if guessed:
        print("You win")
    else:
        print("You Lose")


hangman()