numbers = list(map(int, input()))
if sum(numbers[:len(numbers) // 2]) != sum(numbers[len(numbers) // 2:]):
    print("Not luck!")
else:
    print("Luck!")
